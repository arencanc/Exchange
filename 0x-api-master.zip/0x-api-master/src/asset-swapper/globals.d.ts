declare module 'heartbeats';
